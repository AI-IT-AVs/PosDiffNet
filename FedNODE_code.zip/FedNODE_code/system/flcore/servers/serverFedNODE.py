# -*- coding: utf-8 -*-clients
# Part of the code is referred from: 
# https://github.com/TsingZ0/PFLlib
import time
from flcore.clients.clientFedNODE import clientFedNODE
from flcore.servers.serverbase import Server
from threading import Thread
from collections import defaultdict, OrderedDict
import torch

class FedNODE(Server):
    def __init__(self, args, times):
        super().__init__(args, times)

        self.set_slow_clients()

        self.set_clients(clientFedNODE)
        self.selected_clients = self.clients
        pre_global_rounds = self.pre_global_rounds
        for i in range(pre_global_rounds):
            for client in self.selected_clients:
                client.train() 

        self.uploaded_ids = []
        self.uploaded_weights = []
        tot_samples = 0
        for client in self.selected_clients:
            tot_samples += client.train_samples
            self.uploaded_ids.append(client.id)
            self.uploaded_weights.append(client.train_samples)
        for i, w in enumerate(self.uploaded_weights):
            self.uploaded_weights[i] = w / tot_samples
            
        global_mean = 0
        for cid, w in zip(self.uploaded_ids, self.uploaded_weights):
            global_mean += self.clients[cid].running_mean * w
        for client in self.selected_clients:
            client.global_mean = global_mean.data.clone()

        self.Budget = []


    def train(self):
        for i in range(self.global_rounds+1):
            self.global_model.train()

            s_t = time.time()
            self.selected_clients = self.select_clients()

            if i%self.eval_gap == 0:
                self.evaluate()

            for client in self.selected_clients:
                client_id = torch.tensor([client.id], dtype=torch.long).to(self.device)
                weights = self.global_model(client_id)

                client.model.base.load_state_dict(weights)
                inner_state = OrderedDict({k: tensor.data for k, tensor in weights.items()})

                client.train()

                self.optimizer_hn.zero_grad()

                final_state = client.model.base.state_dict()

                delta_theta = OrderedDict({k: inner_state[k] - final_state[k] for k in weights.keys()})

                hnet_grads = torch.autograd.grad(
                    list(weights.values()), self.global_model.parameters(), grad_outputs=list(delta_theta.values())
                )


                for p, g in zip(self.global_model.parameters(), hnet_grads):
                    p.grad = g

                torch.nn.utils.clip_grad_norm_(self.global_model.parameters(), 50)
                self.optimizer_hn.step()

            self.Budget.append(time.time() - s_t)
            print('-'*25, 'time cost', '-'*25, self.Budget[-1])

            if self.auto_break and self.check_done(acc_lss=[self.rs_test_acc], top_cnt=self.top_cnt):
                break

        self.save_results()
        self.save_global_model()
