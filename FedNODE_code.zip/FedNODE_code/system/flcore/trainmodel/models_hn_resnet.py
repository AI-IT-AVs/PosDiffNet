import torch.nn.functional as F
from torch import nn
from torch.nn.utils import spectral_norm
import torch
from torchdiffeq import odeint

from flcore.trainmodel.models_transformer import vanilla_TransformerLayer



class fc_odefunc(nn.Module):
    def __init__(self, hidden_dim=512):
        super(fc_odefunc, self).__init__()

        self.hidden_dim = hidden_dim

        self.fc_s = nn.Sequential(nn.Linear(self.hidden_dim, self.hidden_dim),
                                  nn.Tanh(),
                                  nn.Linear(self.hidden_dim, self.hidden_dim),
                                  )

    def forward(self, t, x):
        return self.fc_s(x)
    
class fc_ode_layers(nn.Module):
    def __init__(self, hidden_dim=512):
        super(fc_ode_layers, self).__init__()

        self.hidden_dim = hidden_dim

        self.odeint = odeint
        
        tol_scale = torch.tensor([1.0])
        self.atol = tol_scale * 1e-3
        self.rtol = tol_scale * 1e-3
        
        self.odefunc = fc_odefunc(hidden_dim)
        
        self.method = 'euler'
        self.step_size = torch.tensor([1.0]).float()
        self.t = torch.tensor([0, 2.0]).float()


    def forward(self, x):
        device = x.device
        self.t = self.t.to(device)
        self.step_size = self.step_size.to(device)
        self.atol= self.atol.to(device)
        self.rtol= self.rtol.to(device)
        
        t = self.t.type_as(x)
        integrator = self.odeint
        func = self.odefunc
        state = x
        state_dt = integrator(
            func, state, t,
            method=self.method,
            options={'step_size': self.step_size},
            atol=self.atol,
            rtol=self.rtol)
        z = state_dt[1]
        
        z_out = z
        return z_out


class LocalLayer_resnet(nn.Module):

    def __init__(self, n_input=512, n_output=2, nonlinearity=False):
        super(LocalLayer_resnet, self).__init__()
        self.nonlinearity = nonlinearity
        layers = []
        if nonlinearity:
            layers.append(nn.ReLU())

        layers.append(nn.Linear(n_input, n_output))
        self.layer = nn.Sequential(*layers)

        self.fc_ode_layers = fc_ode_layers(hidden_dim=n_input)

        self.fc_layers = nn.Sequential(
                                       nn.Linear(n_input, n_input),
                                       nn.Tanh(),
                                       nn.Linear(n_input, n_input),
                                       nn.Tanh(),
                                       nn.Linear(n_input, n_input),
                                       )



    def forward(self, x):

        x_input_x = self.fc_layers(x)
        x_input = self.fc_ode_layers(x_input_x) 
        x_input = x_input + x_input_x


        x_out = self.layer(x_input)
        return x_out

class mlp_odefunc(nn.Module):
    def __init__(self, hidden_dim=100, n_hidden=1):
        super(mlp_odefunc, self).__init__()

        self.hidden_dim = hidden_dim
        self.n_hidden = n_hidden

        layers_s = [
        ]

        for _ in range(n_hidden):
            layers_s.append(nn.ReLU(inplace=True))
            layers_s.append(nn.Linear(self.hidden_dim, self.hidden_dim))


        self.mlp_s = nn.Sequential(*layers_s)

    def forward(self, t, x):
        return self.mlp_s(x)
    
class mlp_ode_layers(nn.Module):
    def __init__(self, hidden_dim=100, n_hidden=2):
        super(mlp_ode_layers, self).__init__()

        self.hidden_dim = hidden_dim
        self.n_hidden = 2 #2 #n_hidden

        self.odeint = odeint
        
        tol_scale = torch.tensor([1.0])
        self.atol = tol_scale * 1e-3
        self.rtol = tol_scale * 1e-3
        
        self.odefunc = mlp_odefunc(hidden_dim, n_hidden)
        
        
        self.method = 'euler'
        self.step_size = torch.tensor([1.0]).float()
        self.t = torch.tensor([0, 2.0]).float()



    def forward(self, x):
        device = x.device
        self.t = self.t.to(device)
        self.step_size = self.step_size.to(device)
        self.atol= self.atol.to(device)
        self.rtol= self.rtol.to(device)
        
        t = self.t.type_as(x)
        integrator = self.odeint
        func = self.odefunc
        state = x
        state_dt = integrator(
            func, state, t,
            method=self.method,
            options={'step_size': self.step_size},
            atol=self.atol,
            rtol=self.rtol)
        z = state_dt[1]
        
        z_out = z
        return z_out

class mlp_odefunc_T(nn.Module):
    def __init__(self, hidden_dim=100, n_hidden=1):
        super(mlp_odefunc_T, self).__init__()

        self.hidden_dim = hidden_dim
        self.n_hidden = n_hidden

        layers_s = []
        for _ in range(n_hidden):

            layers_s.append(nn.Linear(self.hidden_dim, self.hidden_dim))
            layers_s.append(nn.ReLU())

        self.mlp_s = nn.Sequential(*layers_s)

    def forward(self, t, x):
        return self.mlp_s(x)
    
class mlp_ode_layers_T(nn.Module):
    def __init__(self, hidden_dim=100, n_hidden=1):
        super(mlp_ode_layers_T, self).__init__()

        self.hidden_dim = hidden_dim
        self.n_hidden = 2 

        self.odeint = odeint
        
        tol_scale = torch.tensor([1.0])
        self.atol = tol_scale * 1e-3#
        self.rtol = tol_scale * 1e-3#
        
        self.odefunc = mlp_odefunc_T(hidden_dim, n_hidden)
        
        self.method = 'euler'
        self.step_size = torch.tensor([1.0]).float()
        self.t = torch.tensor([2.0, 0.0]).float()

    def forward(self, x):
        device = x.device
        self.t = self.t.to(device)
        self.step_size = self.step_size.to(device)
        self.atol= self.atol.to(device)
        self.rtol= self.rtol.to(device)
        
        t = self.t.type_as(x)
        integrator = self.odeint
        func = self.odefunc
        state = x
        state_dt = integrator(
            func, state, t,
            method=self.method,
            options={'step_size': self.step_size},
            atol=self.atol,
            rtol=self.rtol)
        z = state_dt[1]
        
        z_out = z
        return z_out


class CNNHyperPC_resnet(nn.Module):
    def __init__(
            self, n_nodes, embedding_dim, n_kernels=64, hidden_dim=100, spec_norm=False, n_hidden=1, 
            in_channels=3, out_dim=512, num_classes=10, dim=1024):
        super().__init__()

        self.num_classes = num_classes
        self.dim = dim

        self.in_channels = in_channels
        self.out_dim = out_dim
        self.n_kernels = n_kernels
        self.embeddings = nn.Embedding(num_embeddings=n_nodes, embedding_dim=embedding_dim)

 
        layers_vanilla = []
        layers_vanilla.append(spectral_norm(nn.Linear(embedding_dim, hidden_dim)) if spec_norm else nn.Linear(embedding_dim, hidden_dim),)

        layers_vanilla.append(nn.ReLU(inplace=True))
        layers_vanilla.append(
            spectral_norm(nn.Linear(hidden_dim, hidden_dim)) if spec_norm else nn.Linear(hidden_dim, hidden_dim),
        )
        layers_vanilla.append(nn.ReLU(inplace=True))
        layers_vanilla.append(
            spectral_norm(nn.Linear(hidden_dim, hidden_dim)) if spec_norm else nn.Linear(hidden_dim, hidden_dim),
        )
        layers_vanilla.append(nn.ReLU(inplace=True))
        layers_vanilla.append(
            spectral_norm(nn.Linear(hidden_dim, hidden_dim)) if spec_norm else nn.Linear(hidden_dim, hidden_dim),
        )


        self.mlp_vanilla = nn.Sequential(*layers_vanilla)

        self.fc_onelayer = nn.Linear(hidden_dim, hidden_dim)


        self.mlp_ode = mlp_ode_layers(hidden_dim, n_hidden)
        self.mlp_ode_T = mlp_ode_layers_T(hidden_dim, n_hidden)



        num_heads = 1
        activation_fn = 'ReLU'
        self.transformer = vanilla_TransformerLayer(embedding_dim, num_heads, dropout=None, activation_fn=activation_fn)



        self.c1_weights = nn.Linear(hidden_dim, self.n_kernels * self.in_channels * 3 * 3)
        self.l1_0_c1_weights = nn.Linear(hidden_dim, self.n_kernels * self.n_kernels)
        self.l1_0_c2_weights = nn.Linear(hidden_dim, self.n_kernels * self.n_kernels)
        self.l1_1_c1_weights = nn.Linear(hidden_dim, self.n_kernels * self.n_kernels)
        self.l1_1_c2_weights = nn.Linear(hidden_dim, self.n_kernels * self.n_kernels)
        self.l2_0_c1_weights = nn.Linear(hidden_dim, 2*self.n_kernels * self.n_kernels)
        self.l2_0_c2_weights = nn.Linear(hidden_dim, 2*self.n_kernels * 2*self.n_kernels)
        self.l2_0_s_weights = nn.Linear(hidden_dim, 2*self.n_kernels * self.n_kernels)
        self.l2_1_c1_weights = nn.Linear(hidden_dim, 2*self.n_kernels * 2*self.n_kernels)
        self.l2_1_c2_weights = nn.Linear(hidden_dim, 2*self.n_kernels * 2*self.n_kernels)
        self.l3_0_c1_weights = nn.Linear(hidden_dim, 4*self.n_kernels * 2*self.n_kernels)
        self.l3_0_c2_weights = nn.Linear(hidden_dim, 4*self.n_kernels * 4*self.n_kernels)
        self.l3_0_s_weights = nn.Linear(hidden_dim, 4*self.n_kernels * 2*self.n_kernels)
        self.l3_1_c1_weights = nn.Linear(hidden_dim, 4*self.n_kernels * 4*self.n_kernels)
        self.l3_1_c2_weights = nn.Linear(hidden_dim, 4*self.n_kernels * 4*self.n_kernels) 
        self.l4_0_c1_weights = nn.Linear(hidden_dim, 8*self.n_kernels * 4*self.n_kernels)
        self.l4_0_c2_weights = nn.Linear(hidden_dim, 8*self.n_kernels * 8*self.n_kernels)
        self.l4_0_s_weights = nn.Linear(hidden_dim, 8*self.n_kernels * 4*self.n_kernels)
        self.l4_1_c1_weights = nn.Linear(hidden_dim, 8*self.n_kernels * 8*self.n_kernels)
        self.l4_1_c2_weights = nn.Linear(hidden_dim, 8*self.n_kernels * 8*self.n_kernels)
        self.fc_weights = nn.Linear(hidden_dim, self.out_dim * 8*self.n_kernels)
        self.fc_bias = nn.Linear(hidden_dim, self.out_dim)


        if spec_norm:


            self.c1_weights = spectral_norm(self.c1_weights)
            self.l1_0_c1_weights = spectral_norm(self.l1_0_c1_weights)
            self.l1_0_c2_weights = spectral_norm(self.l1_0_c2_weights)
            self.l1_1_c1_weights = spectral_norm(self.l1_1_c1_weights)
            self.l1_1_c2_weights = spectral_norm(self.l1_1_c2_weights)
            self.l2_0_c1_weights = spectral_norm(self.l2_0_c1_weights)
            self.l2_0_c2_weights = spectral_norm(self.l2_0_c2_weights)
            self.l2_0_s_weights = spectral_norm(self.l2_0_s_weights)
            self.l2_1_c1_weights = spectral_norm(self.l2_1_c1_weights)
            self.l2_1_c2_weights = spectral_norm(self.l2_1_c2_weights)
            self.l3_0_c1_weights = spectral_norm(self.l3_0_c1_weights)
            self.l3_0_c2_weights = spectral_norm(self.l3_0_c2_weights)
            self.l3_0_s_weights = spectral_norm(self.l3_0_s_weights)
            self.l3_1_c1_weights = spectral_norm(self.l3_1_c1_weights)
            self.l3_1_c2_weights = spectral_norm(self.l3_1_c2_weights)
            self.l4_0_c1_weights = spectral_norm(self.l4_0_c1_weights)
            self.l4_0_c2_weights = spectral_norm(self.l4_0_c2_weights)
            self.l4_0_s_weights = spectral_norm(self.l4_0_s_weights)
            self.l4_1_c1_weights = spectral_norm(self.l4_1_c1_weights)
            self.l4_1_c2_weights = spectral_norm(self.l4_1_c2_weights)
            self.fc_weights = spectral_norm(self.fc_weights)
            self.fc_bias = spectral_norm(self.fc_bias)

            

    def forward(self, idx):

        
        emd_em = self.embeddings(idx)
        emd_trans = self.transformer(emd_em, emd_em)

        emd_trans_w = emd_em + emd_trans
        emd_trans_w_trans = self.transformer(emd_trans_w, emd_trans_w)
        emd = emd_trans_w_trans


        features_vanilla = self.mlp_vanilla(emd)

        features_ode_input = features_vanilla
        features_ode = self.mlp_ode(features_ode_input)
        features_ode_output= self.fc_onelayer(features_ode) 

        features_ode_T = self.mlp_ode_T((features_ode+features_ode_output)/2)

        features = features_ode_T


        weights = {
            "conv1.weight": self.c1_weights(features).view(self.n_kernels, self.in_channels, 3, 3),
            "layer1.0.bkconv1.weight": self.l1_0_c1_weights(features).view(self.n_kernels, self.n_kernels, 1, 1),
            "layer1.0.bkconv2.weight": self.l1_0_c2_weights(features).view(self.n_kernels, self.n_kernels, 1, 1),
            "layer1.1.bkconv1.weight": self.l1_1_c1_weights(features).view(self.n_kernels, self.n_kernels, 1, 1),
            "layer1.1.bkconv2.weight": self.l1_1_c2_weights(features).view(self.n_kernels, self.n_kernels, 1, 1),
            "layer2.0.bkconv1.weight": self.l2_0_c1_weights(features).view(2*self.n_kernels, self.n_kernels, 1, 1),
            "layer2.0.bkconv2.weight": self.l2_0_c2_weights(features).view(2*self.n_kernels, 2*self.n_kernels, 1, 1),
            "layer2.0.shortcut.weight": self.l2_0_s_weights(features).view(2*self.n_kernels, self.n_kernels, 1, 1),
            "layer2.1.bkconv1.weight": self.l2_1_c1_weights(features).view(2*self.n_kernels, 2*self.n_kernels, 1, 1),
            "layer2.1.bkconv2.weight": self.l2_1_c2_weights(features).view(2*self.n_kernels, 2*self.n_kernels, 1, 1),
            "layer3.0.bkconv1.weight": self.l3_0_c1_weights(features).view(4*self.n_kernels, 2*self.n_kernels, 1, 1),
            "layer3.0.bkconv2.weight": self.l3_0_c2_weights(features).view(4*self.n_kernels, 4*self.n_kernels, 1, 1),
            "layer3.0.shortcut.weight": self.l3_0_s_weights(features).view(4*self.n_kernels, 2*self.n_kernels, 1, 1),
            "layer3.1.bkconv1.weight": self.l3_1_c1_weights(features).view(4*self.n_kernels, 4*self.n_kernels, 1, 1),
            "layer3.1.bkconv2.weight": self.l3_1_c2_weights(features).view(4*self.n_kernels, 4*self.n_kernels, 1, 1),
            "layer4.0.bkconv1.weight": self.l4_0_c1_weights(features).view(8*self.n_kernels, 4*self.n_kernels, 1, 1),
            "layer4.0.bkconv2.weight": self.l4_0_c2_weights(features).view(8*self.n_kernels, 8*self.n_kernels, 1, 1),
            "layer4.0.shortcut.weight": self.l4_0_s_weights(features).view(8*self.n_kernels, 4*self.n_kernels, 1, 1),
            "layer4.1.bkconv1.weight": self.l4_1_c1_weights(features).view(8*self.n_kernels, 8*self.n_kernels, 1, 1),
            "layer4.1.bkconv2.weight": self.l4_1_c2_weights(features).view(8*self.n_kernels, 8*self.n_kernels, 1, 1),
            "fc.weight": self.fc_weights(features).view(self.out_dim, 8*self.n_kernels),
            "fc.bias": self.fc_bias(features).view(-1),
        }


        return weights

