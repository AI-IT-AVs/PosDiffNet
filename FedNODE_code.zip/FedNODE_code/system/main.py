#!/usr/bin/env python
# Part of the code is referred from: 
# https://github.com/TsingZ0/PFLlib
import copy
import torch
import argparse
import os
import time
import warnings
import numpy as np
import torchvision
import logging

from flcore.servers.serverFedNODE import FedNODE

from flcore.trainmodel.models import *

from flcore.trainmodel.bilstm import *
from flcore.trainmodel.resnet import *
from flcore.trainmodel.alexnet import *
from flcore.trainmodel.mobilenet_v2 import *
from flcore.trainmodel.transformer import *
from flcore.trainmodel.models_hn import CNNHyperPC, LocalLayer

from flcore.trainmodel.models_hn_resnet import CNNHyperPC_resnet, LocalLayer_resnet
from flcore.trainmodel.resnet18 import *

from utils.result_utils import average_data
from utils.mem_utils import MemReporter

logger = logging.getLogger()
logger.setLevel(logging.ERROR)

warnings.simplefilter("ignore")
torch.manual_seed(0)

emb_dim=32

def run(args):

    time_list = []
    reporter = MemReporter()
    model_str = args.model

    for i in range(args.prev, args.times):
        start = time.time()

        # Generate args.model

        embed_dim = args.embed_dim
        if embed_dim == -1:
            logging.info("auto embedding size")
            embed_dim = int(1 + args.num_clients / 4)

        if model_str == "cnn": 
            if "MNIST" in args.dataset:
                args.model = LocCNN(in_features=1, output_dim=512, dim=1024).to(args.device)
                args.hmodel = CNNHyperPC(n_nodes = args.num_clients, embedding_dim = embed_dim, hidden_dim = args.hyper_hid, 
                                         n_kernels=32, in_channels=1, out_dim=512, num_classes=args.num_classes, dim=1024).to(args.device)
            elif "Cifar10" in args.dataset:
                args.model = LocCNN(in_features=3, output_dim=512, dim=1600).to(args.device)
                args.hmodel = CNNHyperPC(n_nodes = args.num_clients, embedding_dim = embed_dim, hidden_dim = args.hyper_hid, 
                                         n_kernels=32, in_channels=3, out_dim=512, num_classes=args.num_classes, dim=1600).to(args.device)

            else:
                args.model = LocCNN(in_features=3, output_dim=512, dim=10816).to(args.device)
                args.hmodel = CNNHyperPC(n_nodes = args.num_clients, embedding_dim = embed_dim, hidden_dim = args.hyper_hid, 
                                         n_kernels=32, in_channels=3, out_dim=512, num_classes=args.num_classes, dim=10816).to(args.device)
                
            args.lmodel = LocalLayer(n_input=512, n_output=args.num_classes).to(args.device)

        elif model_str == "dnn": # non-convex
            if "MNIST" in args.dataset:
                args.model = DNN(1*28*28, 100, num_classes=args.num_classes).to(args.device)
            elif "Cifar10" in args.dataset:
                args.model = DNN(3*32*32, 100, num_classes=args.num_classes).to(args.device)
            else:
                args.model = DNN(60, 20, num_classes=args.num_classes).to(args.device)
        
        elif model_str == "resnet":
            args.model = resnet_18(output_dim=512).to(args.device)
            args.hmodel = CNNHyperPC_resnet(n_nodes = args.num_clients, embedding_dim = embed_dim, hidden_dim = args.hyper_hid, 
                                            n_kernels=64, in_channels=3, out_dim=512, num_classes=args.num_classes, dim=512).to(args.device)
            args.lmodel = LocalLayer_resnet(n_input=512, n_output=args.num_classes).to(args.device)

        elif model_str == "alexnet":
            args.model = alexnet(pretrained=False, num_classes=args.num_classes).to(args.device)
    
        elif model_str == "harcnn":
            if args.dataset == 'har':
                args.model = HARCNN(9, dim_hidden=1664, num_classes=args.num_classes, conv_kernel_size=(1, 9), pool_kernel_size=(1, 2)).to(args.device)
            elif args.dataset == 'pamap':
                args.model = HARCNN(9, dim_hidden=3712, num_classes=args.num_classes, conv_kernel_size=(1, 9), pool_kernel_size=(1, 2)).to(args.device)

        else:
            raise NotImplementedError

        print(args.model)

        # select algorithm
        if args.algorithm == "FedNODE":
            args.local = args.lmodel
            args.model = ModelSplit(args.model, args.local)
            server = FedNODE(args, i)
            
        else:
            raise NotImplementedError

        server.train()

        time_list.append(time.time()-start)

    print(f"\nAverage time cost: {round(np.average(time_list), 2)}s.")
    

    # Global average
    average_data(dataset=args.dataset, algorithm=args.algorithm, goal=args.goal, times=args.times)

    print("All done!")

    reporter.report()


if __name__ == "__main__":
    total_start = time.time()

    parser = argparse.ArgumentParser()
    # general
    parser.add_argument('-go', "--goal", type=str, default="test", 
                        help="The goal for this experiment")
    parser.add_argument('-dev', "--device", type=str, default="cuda",
                        choices=["cpu", "cuda"])
    parser.add_argument('-did', "--device_id", type=str, default="0")
    parser.add_argument('-data', "--dataset", type=str, default="TinyImagenet",) 
    parser.add_argument('-nb', "--num_classes", type=int, default=200) 
    parser.add_argument('-m', "--model", type=str, default="cnn") 
    parser.add_argument('-lbs', "--batch_size", type=int, default=10)
    parser.add_argument('-lr', "--local_learning_rate", type=float, default=0.005,
                        help="Local learning rate")
    parser.add_argument('-ld', "--learning_rate_decay", type=bool, default=False)
    parser.add_argument('-ldg', "--learning_rate_decay_gamma", type=float, default=0.99)
    parser.add_argument('-gr', "--global_rounds", type=int, default=1) 
    parser.add_argument('-ls', "--local_epochs", type=int, default= 1, 
                        help="Multiple update steps in one local epoch.")
    parser.add_argument('-algo', "--algorithm", type=str, default="FedNODE")
    parser.add_argument('-jr', "--join_ratio", type=float, default=1.0,
                        help="Ratio of clients per round")
    parser.add_argument('-rjr', "--random_join_ratio", type=bool, default= False, 
                        help="Random ratio of clients per round")
    parser.add_argument('-nc', "--num_clients", type=int, default=20,
                        help="Total number of clients")
    parser.add_argument('-pv', "--prev", type=int, default=0,
                        help="Previous Running times")
    parser.add_argument('-t', "--times", type=int, default=1,
                        help="Running times")
    parser.add_argument('-eg', "--eval_gap", type=int, default=1,
                        help="Rounds gap for evaluation")
    parser.add_argument('-dp', "--privacy", type=bool, default=False,
                        help="differential privacy")
    parser.add_argument('-dps', "--dp_sigma", type=float, default=0.0)
    parser.add_argument('-sfn', "--save_folder_name", type=str, default='items')
    parser.add_argument('-ab', "--auto_break", type=bool, default=False)
    parser.add_argument('-dlg', "--dlg_eval", type=bool, default=False)
    parser.add_argument('-dlgg', "--dlg_gap", type=int, default=100)
    parser.add_argument('-bnpc', "--batch_num_per_client", type=int, default=2)
    parser.add_argument('-nnc', "--num_new_clients", type=int, default=0)
    parser.add_argument('-fte', "--fine_tuning_epoch", type=int, default=0)
    # practical
    parser.add_argument('-cdr', "--client_drop_rate", type=float, default=0.0,
                        help="Rate for clients that train but drop out")
    parser.add_argument('-tsr', "--train_slow_rate", type=float, default=0.0,
                        help="The rate for slow clients when training locally")
    parser.add_argument('-ssr', "--send_slow_rate", type=float, default=0.0,
                        help="The rate for slow clients when sending global model")
    parser.add_argument('-ts', "--time_select", type=bool, default=False,
                        help="Whether to group and select clients at each round according to time cost")
    parser.add_argument('-tth', "--time_threthold", type=float, default=10000,
                        help="The threthold for droping slow clients")
    # FedNODE
    parser.add_argument('-mo', "--momentum", type=float, default=0.1)
    parser.add_argument('-klw', "--kl_weight", type=float, default=0.01)
    # Hypernet
    parser.add_argument('-ed', "--embed_dim", type=int, default=-1)
    parser.add_argument('-hh', "--hyper_hid", type=int, default=100, help="hypernet hidden dim")
    parser.add_argument('-edlrhn', "--embed_lr_hn", type=float, default=5e-2, help="embedding learning rate")
    parser.add_argument('-lrhn', "--lr_hn", type=float, default=5e-2, help="learning rate")
    parser.add_argument('-wdhn', "--wd_hn", type=float, default=1e-3, help="weight decay")
    parser.add_argument('-mthn', "--monentum_hn", type=float, default=0.9, help="momentum")
    parser.add_argument('-opthn', "--optim_hn", type=str, default='sgd', choices=['adam', 'sgd'], help="learning rate")
    parser.add_argument('-inwd', "--inner_wd", type=float, default=5e-5, help="inner weight decay")
    parser.add_argument('-pgr', "--pre_global_rounds", type=int, default=1)





    args = parser.parse_args()

    os.environ["CUDA_VISIBLE_DEVICES"] = args.device_id

    if args.device == "cuda" and not torch.cuda.is_available():
        print("\ncuda is not avaiable.\n")
        args.device = "cpu"

 
    run(args)
