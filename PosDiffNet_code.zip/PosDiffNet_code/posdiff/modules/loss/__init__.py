from posdiff.modules.loss.circle_loss import CircleLoss, WeightedCircleLoss

