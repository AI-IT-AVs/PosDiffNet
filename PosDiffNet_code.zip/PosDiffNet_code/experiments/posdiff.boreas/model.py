import torch
import torch.nn as nn
import torch.nn.functional as F
from IPython import embed

from posdiff.modules.ops import point_to_node_partition, index_select
from posdiff.modules.registration import get_node_correspondences
from posdiff.modules.sinkhorn import LearnableLogOptimalTransport
from posdiff.modules.posdiff import (
    PosDiffTransformer,
    SuperPointMatching,
    SuperPointTargetGenerator,
    LocalGlobalRegistration,
)

from backbone import KPConvFPN

from posdiff.modules.posdiff.posidff_module import PosDiffNet
from torchdiffeq import odeint
import open3d as o3d
from sklearn.cluster import DBSCAN, HDBSCAN
import numpy as np
from posdiff.modules.posdiff.posdiff import Transformer_vanilla
from posdiff.modules.ops import grid_subsample, radius_search
from util_dgcnn import DGCNN


def radius_outlier(points, nb_points = 5, radius = 0.05):
    points = points.cpu().numpy()
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)
    c1, index = pcd.remove_radius_outlier(nb_points=nb_points, radius=radius)
    return index

class PosDiffuNet_model(nn.Module):
    def __init__(self, cfg):
        super(PosDiffuNet_model, self).__init__()
        self.num_points_in_patch = cfg.model.num_points_in_patch
        self.matching_radius = cfg.model.ground_truth_matching_radius
        self.num_points_in_win = cfg.model.num_points_in_win
        self.nb_points = cfg.outlier_filter.nb_points
        self.outlier_radius = cfg.outlier_filter.outlier_radius
        self.matching_radius_win = cfg.model.ground_truth_matching_radius_win

        self.backbone = KPConvFPN(
            cfg.backbone.input_dim,
            cfg.backbone.output_dim,
            cfg.backbone.init_dim,
            cfg.backbone.kernel_size,
            cfg.backbone.init_radius,
            cfg.backbone.init_sigma,
            cfg.backbone.group_norm,
        )

        self.posdiff_layer_f = PosDiffNet(emb_dims = cfg.backbone.output_dim*2)
        self.posdiff_layer_c = PosDiffNet(emb_dims = cfg.posdiff.input_dim*2)

        self.transformer_win = Transformer_vanilla(
            cfg.backbone.output_dim*2,
            cfg.posdiff.output_dim,
            cfg.posdiff.hidden_dim,
            cfg.posdiff.num_heads,
            cfg.posdiff.blocks_win,
            reduction_a=cfg.posdiff.reduction_a,
        )
        self.coarse_matching_win = SuperPointMatching(
            cfg.coarse_matching.num_correspondences_win, cfg.coarse_matching.dual_normalization
        )
        self.coarse_target_win = SuperPointTargetGenerator(
            cfg.coarse_matching.num_targets_win, cfg.coarse_matching.overlap_threshold_win
        )
        self.dgcnn = DGCNN(emb_dims = cfg.backbone.output_dim*2)

        self.transformer = PosDiffTransformer(
            cfg.posdiff.input_dim,
            cfg.posdiff.output_dim,
            cfg.posdiff.hidden_dim,
            cfg.posdiff.num_heads,
            cfg.posdiff.blocks,
            reduction_a=cfg.posdiff.reduction_a,
        )

        self.coarse_target = SuperPointTargetGenerator(
            cfg.coarse_matching.num_targets, cfg.coarse_matching.overlap_threshold
        )

        self.coarse_matching = SuperPointMatching(
            cfg.coarse_matching.num_correspondences, cfg.coarse_matching.dual_normalization
        )

        self.fine_matching = LocalGlobalRegistration(
            cfg.fine_matching.topk,
            cfg.fine_matching.acceptance_radius,
            mutual=cfg.fine_matching.mutual,
            confidence_threshold=cfg.fine_matching.confidence_threshold,
            use_dustbin=cfg.fine_matching.use_dustbin,
            use_global_score=cfg.fine_matching.use_global_score,
            correspondence_threshold=cfg.fine_matching.correspondence_threshold,
            correspondence_limit=cfg.fine_matching.correspondence_limit,
            num_refinement_steps=cfg.fine_matching.num_refinement_steps,
        )

        self.optimal_transport = LearnableLogOptimalTransport(cfg.model.num_sinkhorn_iterations)

    def forward(self, data_dict):
        output_dict = {}

        feats = data_dict['features'].detach()
        transform = data_dict['transform'].detach()

        ref_length_win = data_dict['lengths'][-1][0].item()
        ref_length_c = data_dict['lengths'][-2][0].item()
        ref_length_f = data_dict['lengths'][1][0].item()
        ref_length = data_dict['lengths'][0][0].item()
        points_win = data_dict['points'][-1].detach()
        points_c = data_dict['points'][-2].detach()
        points_f = data_dict['points'][1].detach()
        points = data_dict['points'][0].detach()
        ref_points_win = points_win[:ref_length_win]
        src_points_win = points_win[ref_length_win:]
        ref_points_c = points_c[:ref_length_c]
        src_points_c = points_c[ref_length_c:]
        ref_points_f = points_f[:ref_length_f]
        src_points_f = points_f[ref_length_f:]
        ref_points = points[:ref_length]
        src_points = points[ref_length:]

        feats_list = self.backbone(feats, data_dict)

        feats_c = feats_list[-1]
        feats_f = feats_list[0]

        feat_c_len = feats_c.shape[0]

        ref_feats_c = feats_c[:ref_length_c] 
        src_feats_c = feats_c[ref_length_c:] 
        ref_feats_f = feats_f[:ref_length_f] 
        src_feats_f = feats_f[ref_length_f:] 

        device = feats_c.device
        ref_feats_c_pos = torch.zeros_like(ref_feats_c).to(device) 
        src_feats_c_pos = torch.zeros_like(src_feats_c).to(device) 
        ref_feats_c_pos[:, 0:3] = ref_points_c 
        src_feats_c_pos[:, 0:3] = src_points_c 
        ref_feats_c_pp = torch.cat([ref_feats_c, ref_feats_c_pos], dim=1) 
        src_feats_c_pp =  torch.cat([src_feats_c, src_feats_c_pos], dim=1)
        ref_feats_c_pp_out = self.posdiff_layer_c(ref_feats_c_pp.transpose(1,0).unsqueeze(0)) 
        src_feats_c_pp_out = self.posdiff_layer_c(src_feats_c_pp.transpose(1,0).unsqueeze(0)) 
        ref_feats_c_pp_out = ref_feats_c_pp_out.squeeze(0).transpose(1,0) 
        src_feats_c_pp_out = src_feats_c_pp_out.squeeze(0).transpose(1,0) 
        ref_feats_c = ref_feats_c_pp_out[:, :ref_feats_c_pp_out.shape[1]//2]   
        src_feats_c = src_feats_c_pp_out[:, :src_feats_c_pp_out.shape[1]//2]  
        ref_feats_c_pos = ref_feats_c_pp_out[:, ref_feats_c_pp_out.shape[1]//2:] 
        src_feats_c_pos = src_feats_c_pp_out[:, src_feats_c_pp_out.shape[1]//2:] 
        ref_feats_f_pos = torch.zeros_like(ref_feats_f).to(device) 
        src_feats_f_pos = torch.zeros_like(src_feats_f).to(device)
        ref_feats_f_pos[:, 0:3] = ref_points_f 
        src_feats_f_pos[:, 0:3] = src_points_f
        ref_feats_f_pp = torch.cat([ref_feats_f, ref_feats_f_pos], dim=1) 
        src_feats_f_pp =  torch.cat([src_feats_f, src_feats_f_pos], dim=1) 
        ref_feats_f_pp_out = self.posdiff_layer_f(ref_feats_f_pp.transpose(1,0).unsqueeze(0)) 
        src_feats_f_pp_out = self.posdiff_layer_f(src_feats_f_pp.transpose(1,0).unsqueeze(0))
        ref_feats_f_pp_out = ref_feats_f_pp_out.squeeze(0).transpose(1,0)
        src_feats_f_pp_out = src_feats_f_pp_out.squeeze(0).transpose(1,0) 
        ref_feats_f = ref_feats_f_pp_out[:, :ref_feats_f_pp_out.shape[1]//2] 
        src_feats_f = src_feats_f_pp_out[:, :src_feats_f_pp_out.shape[1]//2] 
        ref_feats_f_pos = ref_feats_f_pp_out[:, ref_feats_f_pp_out.shape[1]//2:] 
        src_feats_f_pos = src_feats_f_pp_out[:, src_feats_f_pp_out.shape[1]//2:] 

        _, ref_win_masks, ref_win_knn_indices, ref_win_knn_masks = point_to_node_partition(
            ref_points_c, ref_points_win, self.num_points_in_win
        )

        _, src_win_masks, src_win_knn_indices, src_win_knn_masks = point_to_node_partition(
            src_points_c, src_points_win, self.num_points_in_win
        ) 

        ref_win_padded_points_c = torch.cat([ref_points_c, torch.zeros_like(ref_points_c[:1])], dim=0)
        src_win_padded_points_c = torch.cat([src_points_c, torch.zeros_like(src_points_c[:1])], dim=0)
        ref_win_knn_points = index_select(ref_win_padded_points_c, ref_win_knn_indices, dim=0)  
        src_win_knn_points = index_select(src_win_padded_points_c, src_win_knn_indices, dim=0) 

        ref_feats_win = self.dgcnn(ref_points_win.transpose(1,0).unsqueeze(0))
        src_feats_win = self.dgcnn(src_points_win.transpose(1,0).unsqueeze(0))
        ref_feats_win = ref_feats_win.squeeze(0).transpose(1,0)
        src_feats_win = src_feats_win.squeeze(0).transpose(1,0)


        ref_feats_win_trans, src_feats_win_trans = self.transformer_win(
            ref_feats_win.unsqueeze(0),
            src_feats_win.unsqueeze(0),
        )
        ref_feats_win_norm = F.normalize(ref_feats_win_trans.squeeze(0), p=2, dim=1)
        src_feats_win_norm = F.normalize(src_feats_win_trans.squeeze(0), p=2, dim=1)

        gt_win_corr_indices, gt_win_corr_overlaps = get_node_correspondences(
            ref_points_win,
            src_points_win,
            ref_win_knn_points,
            src_win_knn_points,
            transform,
            self.matching_radius_win,
            ref_masks=ref_win_masks,
            src_masks=src_win_masks,
            ref_knn_masks=ref_win_knn_masks,
            src_knn_masks=src_win_knn_masks,
        ) 

        with torch.no_grad():
            ref_win_corr_indices, src_win_corr_indices, win_corr_scores = self.coarse_matching_win(
                ref_feats_win_norm, src_feats_win_norm, ref_win_masks, src_win_masks
            )
            if self.training:
                ref_win_corr_indices, src_win_corr_indices, win_corr_scores = self.coarse_target_win(
                    gt_win_corr_indices, gt_win_corr_overlaps
                )

        ref_win_knn_indices = ref_win_knn_indices[ref_win_corr_indices]  
        src_win_knn_indices = src_win_knn_indices[src_win_corr_indices]  
        ref_points_win = ref_points_win[ref_win_corr_indices]
        src_points_win = src_points_win[src_win_corr_indices]
        ref_win_corr_clustering_indices = radius_outlier(ref_points_win, self.nb_points, self.outlier_radius)
        src_win_corr_clustering_indices = radius_outlier(src_points_win, self.nb_points, self.outlier_radius)
        ref_points_win = ref_points_win[ref_win_corr_clustering_indices,:]
        src_points_win = src_points_win[src_win_corr_clustering_indices,:]
        ref_win_knn_indices = ref_win_knn_indices[ref_win_corr_clustering_indices]
        src_win_knn_indices = src_win_knn_indices[src_win_corr_clustering_indices]
 

        ref_win_corr_knn_indices = ref_win_knn_indices 
        src_win_corr_knn_indices = src_win_knn_indices  

        ref_win_c_indices = torch.unique(ref_win_corr_knn_indices.view(-1,))
        src_win_c_indices = torch.unique(src_win_corr_knn_indices.view(-1,))
        ref_win_c_indices = ref_win_c_indices[ref_win_c_indices<ref_length_c]
        src_win_c_indices = src_win_c_indices[src_win_c_indices<feat_c_len-ref_length_c]

        ref_points_c = ref_points_c[ref_win_c_indices]
        src_points_c = src_points_c[src_win_c_indices]
        ref_feats_c = ref_feats_c[ref_win_c_indices]
        src_feats_c = src_feats_c[src_win_c_indices]
        ref_feats_c_pos = ref_feats_c_pos[ref_win_c_indices]
        src_feats_c_pos = src_feats_c_pos[src_win_c_indices]

        output_dict['ref_points_win'] = ref_points_win 
        output_dict['src_points_win'] = src_points_win 
        output_dict['ref_points_c'] = ref_points_c
        output_dict['src_points_c'] = src_points_c 
        output_dict['ref_points_f'] = ref_points_f 
        output_dict['src_points_f'] = src_points_f 
        output_dict['ref_points'] = ref_points   
        output_dict['src_points'] = src_points  

        _, ref_node_masks, ref_node_knn_indices, ref_node_knn_masks = point_to_node_partition(
            ref_points_f, ref_points_c, self.num_points_in_patch
        )
        _, src_node_masks, src_node_knn_indices, src_node_knn_masks = point_to_node_partition(
            src_points_f, src_points_c, self.num_points_in_patch
        )

        ref_padded_points_f = torch.cat([ref_points_f, torch.zeros_like(ref_points_f[:1])], dim=0)
        src_padded_points_f = torch.cat([src_points_f, torch.zeros_like(src_points_f[:1])], dim=0)
        ref_node_knn_points = index_select(ref_padded_points_f, ref_node_knn_indices, dim=0)
        src_node_knn_points = index_select(src_padded_points_f, src_node_knn_indices, dim=0)

        gt_node_corr_indices, gt_node_corr_overlaps = get_node_correspondences(
            ref_points_c,
            src_points_c,
            ref_node_knn_points,
            src_node_knn_points,
            transform,
            self.matching_radius,
            ref_masks=ref_node_masks,
            src_masks=src_node_masks,
            ref_knn_masks=ref_node_knn_masks,
            src_knn_masks=src_node_knn_masks,
        )

        output_dict['gt_node_corr_indices'] = gt_node_corr_indices
        output_dict['gt_node_corr_overlaps'] = gt_node_corr_overlaps


        ref_feats_c, src_feats_c = self.transformer(
            ref_feats_c_pos.unsqueeze(0),
            src_feats_c_pos.unsqueeze(0),
            ref_feats_c.unsqueeze(0),
            src_feats_c.unsqueeze(0),
        )
        ref_feats_c_norm = F.normalize(ref_feats_c.squeeze(0), p=2, dim=1)
        src_feats_c_norm = F.normalize(src_feats_c.squeeze(0), p=2, dim=1)

        output_dict['ref_feats_c'] = ref_feats_c_norm
        output_dict['src_feats_c'] = src_feats_c_norm

        output_dict['ref_feats_f'] = ref_feats_f
        output_dict['src_feats_f'] = src_feats_f

        with torch.no_grad():
            ref_node_corr_indices, src_node_corr_indices, node_corr_scores = self.coarse_matching(
                ref_feats_c_norm, src_feats_c_norm, ref_node_masks, src_node_masks
            )

            output_dict['ref_node_corr_indices'] = ref_node_corr_indices
            output_dict['src_node_corr_indices'] = src_node_corr_indices

            if self.training:
                ref_node_corr_indices, src_node_corr_indices, node_corr_scores = self.coarse_target(
                    gt_node_corr_indices, gt_node_corr_overlaps
                )

        ref_node_corr_knn_indices = ref_node_knn_indices[ref_node_corr_indices] 
        src_node_corr_knn_indices = src_node_knn_indices[src_node_corr_indices]  
        ref_node_corr_knn_masks = ref_node_knn_masks[ref_node_corr_indices]  
        src_node_corr_knn_masks = src_node_knn_masks[src_node_corr_indices]  
        ref_node_corr_knn_points = ref_node_knn_points[ref_node_corr_indices]  
        src_node_corr_knn_points = src_node_knn_points[src_node_corr_indices]  

        ref_padded_feats_f = torch.cat([ref_feats_f, torch.zeros_like(ref_feats_f[:1])], dim=0)
        src_padded_feats_f = torch.cat([src_feats_f, torch.zeros_like(src_feats_f[:1])], dim=0)
        ref_node_corr_knn_feats = index_select(ref_padded_feats_f, ref_node_corr_knn_indices, dim=0)  
        src_node_corr_knn_feats = index_select(src_padded_feats_f, src_node_corr_knn_indices, dim=0) 

        output_dict['ref_node_corr_knn_points'] = ref_node_corr_knn_points
        output_dict['src_node_corr_knn_points'] = src_node_corr_knn_points
        output_dict['ref_node_corr_knn_masks'] = ref_node_corr_knn_masks
        output_dict['src_node_corr_knn_masks'] = src_node_corr_knn_masks

        matching_scores = torch.einsum('bnd,bmd->bnm', ref_node_corr_knn_feats, src_node_corr_knn_feats) 
        matching_scores = matching_scores / feats_f.shape[1] ** 0.5
        matching_scores = self.optimal_transport(matching_scores, ref_node_corr_knn_masks, src_node_corr_knn_masks)

        output_dict['matching_scores'] = matching_scores

        with torch.no_grad():
            if not self.fine_matching.use_dustbin:
                matching_scores = matching_scores[:, :-1, :-1]

            ref_corr_points, src_corr_points, corr_scores, estimated_transform = self.fine_matching(
                ref_node_corr_knn_points,
                src_node_corr_knn_points,
                ref_node_corr_knn_masks,
                src_node_corr_knn_masks,
                matching_scores,
                node_corr_scores,
            )

            output_dict['ref_corr_points'] = ref_corr_points
            output_dict['src_corr_points'] = src_corr_points
            output_dict['corr_scores'] = corr_scores
            output_dict['estimated_transform'] = estimated_transform

        return output_dict


def create_model(cfg):
    model = PosDiffuNet_model(cfg)
    return model


def main():
    from config import make_cfg

    cfg = make_cfg()
    model = create_model(cfg)
    print(model.state_dict().keys())
    print(model)


if __name__ == '__main__':
    main()
