#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Part of the code is referred from: https://github.com/ClementPinard/SfmLearner-Pytorch/blob/master/inverse_warp.py

from __future__ import print_function

import numpy as np
import pynvml
import torch
from scipy.spatial.transform import Rotation
from torch import nn
from torch.nn import functional as F

pynvml.nvmlInit()
handle0 = pynvml.nvmlDeviceGetHandleByIndex(0)
if torch.cuda.device_count() > 1:
    handle1 = pynvml.nvmlDeviceGetHandleByIndex(1)
ratio = 1024 ** 2


def print_gpu(s=""):
    if torch.cuda.device_count() > 1:
        meminfo0 = pynvml.nvmlDeviceGetMemoryInfo(handle0)
        meminfo1 = pynvml.nvmlDeviceGetMemoryInfo(handle0)
        used = (meminfo0.used + meminfo1.used) / ratio
    else:
        meminfo0 = pynvml.nvmlDeviceGetMemoryInfo(handle0)
        used = meminfo0.used / ratio
    print(s + " used: ", used)


class GlobalVar():

    def __init__(self):
        self.self_att_src = None
        self.cross_self_att_src = None
        self.cross_att_src = None
        self.self_att_tgt = None
        self.cross_self_att_tgt = None
        self.cross_att_tgt = None
        self.src = None
        self.tgt = None

    def transform_np(self):

        print(self.self_att_src.shape)
        self.self_att_src = self.format(self.self_att_src)
        self.cross_self_att_src = self.format(self.cross_self_att_src)
        self.cross_att_src = self.format(self.cross_att_src)
        self.self_att_tgt = self.format(self.self_att_tgt)
        self.cross_self_att_tgt = self.format(self.cross_self_att_tgt)
        self.cross_att_tgt = self.format(self.cross_att_tgt)
        self.src = self.format(self.src)
        self.tgt = self.format(self.tgt)

    def format(self, data):

        if type(data) is torch.Tensor:  data = data.detach().cpu().numpy()
        data = np.squeeze(data)
        return data


def quat2mat(quat):
    x, y, z, w = quat[:, 0], quat[:, 1], quat[:, 2], quat[:, 3]

    B = quat.size(0)

    w2, x2, y2, z2 = w.pow(2), x.pow(2), y.pow(2), z.pow(2)
    wx, wy, wz = w * x, w * y, w * z
    xy, xz, yz = x * y, x * z, y * z

    rotMat = torch.stack([w2 + x2 - y2 - z2, 2 * xy - 2 * wz, 2 * wy + 2 * xz,
                          2 * wz + 2 * xy, w2 - x2 + y2 - z2, 2 * yz - 2 * wx,
                          2 * xz - 2 * wy, 2 * wx + 2 * yz, w2 - x2 - y2 + z2], dim=1).reshape(B, 3, 3)
    return rotMat


def transform_point_cloud(point_cloud, rotation, translation):
    if len(rotation.size()) == 2:
        rot_mat = quat2mat(rotation)
    else:
        rot_mat = rotation
    return torch.matmul(rot_mat.type_as(point_cloud), point_cloud) + translation.unsqueeze(2)


def npmat2euler(mats, seq='zyx'):
    eulers = []
    for i in range(mats.shape[0]):
        r = Rotation.from_dcm(mats[i])
        eulers.append(r.as_euler(seq, degrees=True))
    return np.asarray(eulers, dtype='float32')


def farthest_point_sample(xyz, npoint):

    xyz = xyz.transpose(2, 1)
    device = xyz.device
    B, N, C = xyz.shape

    centroids = torch.zeros(B, npoint, dtype=torch.long).to(device) 
    distance = torch.ones(B, N).to(device) * 1e10  

    batch_indices = torch.arange(B, dtype=torch.long).to(device) 

    barycenter = torch.sum((xyz), 1) 
    barycenter = barycenter / xyz.shape[1]
    barycenter = barycenter.view(B, 1, 3)

    dist = torch.sum((xyz - barycenter) ** 2, -1)
    farthest = torch.max(dist, 1)[1] 

    for i in range(npoint):
        centroids[:, i] = farthest 
        centroid = xyz[batch_indices, farthest, :].view(B, 1, 3)  
        dist = torch.sum((xyz - centroid) ** 2, -1)  
        mask = dist < distance
        distance[mask] = dist[mask] 
        farthest = torch.max(distance, -1)[1]

    return centroids


def knn(x, k):

    device = x.device
    inner = -2 * torch.matmul(x.transpose(2, 1).contiguous(), x)  

    xx = torch.sum(x ** 2, dim=1, keepdim=True) 

    pairwise_distance = -xx - inner
    pairwise_distance = pairwise_distance - xx.transpose(2, 1).contiguous() 
    idx = pairwise_distance.topk(k=k + 1, dim=-1)[1][:, :, 1:] 
    return idx


def get_graph_feature(x, k=10, idx=None):
    device = x.device
    batch_size, dims, num_points = x.size()
    x = x.view(batch_size, -1, num_points)
    if idx is None:
        idx = knn(x, k=k) 
    idx = idx.to(device)
   

    idx_base = torch.arange(0, batch_size, device=device).view(-1, 1, 1) * num_points  
    idx_base = idx_base.to(device)
    idx = idx + idx_base  

    idx = idx.view(-1)  
    x = x.transpose(2, 1).contiguous()  

    feature = x.view(batch_size * num_points, -1)[idx, :] 

    feature = feature.view(batch_size, num_points, k, dims)  

    x = x.view(batch_size, num_points, 1, dims).repeat(1, 1, k, 1) 

    feature = torch.cat((feature, x), dim=3).permute(0, 3, 1, 2)  

    return feature


def get_graph_featureNew(x, k=10, idx=None):
    batch_size, dims, num_points = x.size()
    if idx is None:
        idx = knn(x, k=k) 
    idx = idx.view(batch_size, num_points * k).unsqueeze(1).repeat(1, dims, 1)
    feature = torch.gather(x, index=idx, dim=2).view(batch_size, dims, num_points, k)
    x = x.unsqueeze(3).repeat(1, 1, 1, k)
    feature = torch.cat((feature, x), dim=1) 

    return feature

class DGCNN(nn.Module):
    def __init__(self, emb_dims=512):
        super(DGCNN, self).__init__()
        self.conv1 = nn.Conv2d(6, 64, kernel_size=1, bias=False)
        self.conv3 = nn.Conv2d(64, 128, kernel_size=1, bias=False)
        self.conv4 = nn.Conv2d(128, 256, kernel_size=1, bias=False)
        self.conv5 = nn.Conv2d(448, emb_dims, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.bn3 = nn.BatchNorm2d(128)
        self.bn4 = nn.BatchNorm2d(256)
        self.bn5 = nn.BatchNorm2d(emb_dims)

    def forward(self, x):
        batch_size, num_dims, num_points = x.size() 
        x = get_graph_feature(x) 
        x = F.relu(self.bn1(self.conv1(x))) 
        x1 = x.max(dim=-1, keepdim=True)[0] 

        x = F.relu(self.bn3(self.conv3(x)))  
        x3 = x.max(dim=-1, keepdim=True)[0] 

        x = F.relu(self.bn4(self.conv4(x)))  
        x4 = x.max(dim=-1, keepdim=True)[0] 

        x = torch.cat((x1, x3, x4), dim=1)  

        x = F.relu(self.bn5(self.conv5(x))).view(batch_size, -1, num_points) 
        return x
